// Test harness for Ti.FancyLabel.
//
// Exercises the two things we just fixed, plus the core streaming API:
//
//  1. Left-to-right fade sweep - watch each word/character reveal glyph by
//     glyph in writing order, instead of popping in all at once.
//  2. Auto-height inside a parent - each bubble is a Ti.FancyLabel with
//     height: Ti.UI.SIZE, stacked inside a vertical ScrollView. Watch each
//     bubble grow downward to fit its own text (never upward, never past
//     its own rounded-rect background), and the ScrollView's content grow
//     to fit every bubble as messages stream in.
//
// backgroundColor + borderRadius are set on every bubble on purpose, so
// the view's real native bounds are always visible - that's how the old
// "grows upward / ignores parent" bug was caught in the first place.

import FancyLabel from 'ti.fancylabel';

const win = Ti.UI.createWindow({ backgroundColor: '#f2f2f7' });

const scrollView = Ti.UI.createScrollView({
  top: 0, left: 0, right: 0, bottom: 140,
  layout: 'vertical',
  contentWidth: Ti.UI.FILL,
  contentHeight: Ti.UI.SIZE,
  showVerticalScrollIndicator: true
});
win.add(scrollView);

// Everything lives inside this vertical stack. Its own height is
// Ti.UI.SIZE too, so it only grows as far as its children actually need -
// if that stops working, the ScrollView stops growing with it.
const stack = Ti.UI.createView({
  layout: 'vertical',
  top: 12, left: 0, right: 0,
  height: Ti.UI.SIZE,
  width: Ti.UI.FILL
});
scrollView.add(stack);

const controls = Ti.UI.createView({
  bottom: 0, left: 0, right: 0, height: 140,
  backgroundColor: '#ffffff',
  layout: 'vertical'
});
win.add(controls);

const row1 = Ti.UI.createView({ top: 12, left: 12, right: 12, height: 40, layout: 'horizontal' });
controls.add(row1);
const wordButton = Ti.UI.createButton({ title: 'Mensagem (word)', width: Ti.UI.SIZE, height: 36, right: 10 });
const charButton = Ti.UI.createButton({ title: 'Mensagem (character)', width: Ti.UI.SIZE, height: 36 });
row1.add(wordButton);
row1.add(charButton);

const row2 = Ti.UI.createView({ top: 10, left: 12, right: 12, height: 40, layout: 'horizontal' });
controls.add(row2);
const instantButton = Ti.UI.createButton({ title: 'Instantanea (setText)', width: Ti.UI.SIZE, height: 36, right: 10 });
const shortButton = Ti.UI.createButton({ title: 'Mensagem curta', width: Ti.UI.SIZE, height: 36 });
row2.add(instantButton);
row2.add(shortButton);

const row3 = Ti.UI.createView({ top: 10, left: 12, right: 12, height: 40, layout: 'horizontal' });
controls.add(row3);
const clearButton = Ti.UI.createButton({ title: 'Limpar tudo', width: Ti.UI.SIZE, height: 36 });
row3.add(clearButton);

// A couple of long-ish responses (to see wrapping + multi-line growth) and
// one short one (to see the sweep on a single short word/line).
const longResponses = [
  'Ola! Isto e uma demonstracao do Ti.FancyLabel, simulando um stream de texto chegando aos poucos, igual a resposta de um assistente de IA.',
  'Cada nova mensagem cresce dentro do ScrollView sem estourar os limites do container pai, e o proprio ScrollView acompanha esse crescimento em tempo real.',
  'O efeito de fade agora varre da esquerda para a direita, glifo por glifo, dentro de cada palavra ou caractere revelado - inclusive em textos da direita para a esquerda.'
];
let longIndex = 0;

function nextLongResponse() {
  const text = longResponses[longIndex % longResponses.length];
  longIndex += 1;
  return text;
}

function createBubble() {
  const bubble = FancyLabel.createLabel({
    font: { fontSize: 16 },
    color: '#111111',
    backgroundColor: '#e4e9f7', // visual debug: makes the view's real bounds obvious
    borderRadius: 14,
    top: 0, bottom: 10, left: 16, right: 16,
    width: Ti.UI.FILL,
    height: Ti.UI.SIZE
  });
  stack.add(bubble);
  return bubble;
}

function streamInto(bubble, text, granularity) {
  bubble.reset();
  bubble.granularity = granularity;
  bubble.fadeDuration = granularity === 'character' ? 0.18 : 0.35;
  bubble.fadeDelayStep = granularity === 'character' ? 0.015 : 0.03;

  const words = text.split(' ').map((word, i, arr) => (i < arr.length - 1 ? word + ' ' : word));
  let i = 0;
  const timer = setInterval(() => {
    if (i >= words.length) {
      clearInterval(timer);
      bubble.complete();
      scrollToBottom();
      return;
    }
    bubble.appendText(words[i]);
    i += 1;
    scrollToBottom();
  }, 160);
}

// Best-effort auto-scroll: wait for the stack's next layout pass (which
// now fires reliably because of the contentsWillChange() fix), then scroll
// so the newest content stays visible.
function scrollToBottom() {
  stack.addEventListener('postlayout', function onLayout() {
    stack.removeEventListener('postlayout', onLayout);
    const targetY = Math.max((stack.size.height || 0) - (scrollView.size.height || 0) + 40, 0);
    scrollView.scrollTo(0, targetY);
  });
}

wordButton.addEventListener('click', () => {
  streamInto(createBubble(), nextLongResponse(), 'word');
});

charButton.addEventListener('click', () => {
  streamInto(createBubble(), nextLongResponse(), 'character');
});

shortButton.addEventListener('click', () => {
  streamInto(createBubble(), 'Oi!', 'word');
});

instantButton.addEventListener('click', () => {
  const bubble = createBubble();
  bubble.setText(nextLongResponse());
  scrollToBottom();
});

clearButton.addEventListener('click', () => {
  const children = stack.children ? stack.children.slice() : [];
  children.forEach((child) => stack.remove(child));
  longIndex = 0;
});

win.open();

// TODO: once you're happy with the behavior here, swap streamInto()'s
// setInterval simulation for real chunks from Ti.Network.Manager, e.g.:
//
// const bubble = createBubble();
// NetworkManager.stream({
//   url: 'https://api.example.com/chat',
//   onChunk: (chunk) => { bubble.appendText(chunk); scrollToBottom(); },
//   onDone: () => bubble.complete()
// });
